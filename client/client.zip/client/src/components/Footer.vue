<template>
     <!-- Footer -->
  <footer class="section darken-2 white-text center" style="background-color: #B94465 !important;">
    <p class="flow-text"> Belet Clément et Loya Dylan</p>
  </footer>
</template>

<script>
import 'materialize-css'
import 'materialize-css/dist/css/materialize.css'
export default {
    name: 'Footer'
}
</script>

<style lang="css" scoped>
* {
    z-index: 100 !important;
}
</style>
