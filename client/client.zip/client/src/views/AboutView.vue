<template>
  <div class="about">
    <p>This website was created by Belet Clément and Loya Dylan</p>
  </div>
</template>
